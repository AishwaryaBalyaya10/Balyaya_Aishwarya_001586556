Aishwarya Balkrishna Balyaya
NUID: 001586556

Tags present in Assignement4:
List of tags used:
1)	<DOCTYPE> HTML documents must start with a <!DOCTYPE> declaration
2)	<h1> highest level in the HTML document
3)	<h2> 2nd highest level in the HTML document
4)	<h3> 3rd highest level in the HTML document
5)	<p> defines paragraph
6)	<div> container for HTML elements when styled with CSS
7)	<form> container for different types of input elements
8)	<span>inline container used to mark up a part of text
9)	<i> displays in italic
10)	<br> break to next line
11)	<title>Title of the page
12)	<link> Relationship between current document and external source
13)	<head> container for metadata
14)	<style>Add styles to element
15)	<body>defines the main content of html link
16)	<label> label for several elements
17)	<input> create interactive controls for web-based forms in order to accept data from the user
18)	<button> defines clickable button
19)	<font-size> sets the size of font
20)	<font-weight> sets the weight of font
21)	<font-family> sets the family of font
22)	<margin> sets the margin for element
23)	<padding> create space around elements
24)	<display> specifies the display behavior 
25)	<border> specifies what kind of border to display
26)	<width>sets width
27)	<height>sets height

Javascript
•	Validation()
•	fNumbervalidation()
•	fZipValidation()
•	check1()
•	check2()
•	check3()
•	check4()
•	check5()
•	onChangeEvent()
•	addRow()
•	getElementById()
•	querySelector()
•	addEventListener
•	toggle
•	DOM Style property
•	.checked


